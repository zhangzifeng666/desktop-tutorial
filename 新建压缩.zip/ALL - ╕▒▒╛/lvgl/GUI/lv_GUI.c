#include "lvgl.h"
#include "lv_port_disp.h"
#include "lv_port_indev.h"
#include <stdio.h>
extern void set_motor_disable(void);
extern void set_motor_enable(void);
extern void set_motor_speed(uint16_t v);
extern void set_motor_direction(int dir);
float Kp, Ki, Kd;
lv_obj_t * p_parameter;
lv_obj_t * I_parameter;
lv_obj_t * D_parameter;
lv_obj_t * slider_label;
lv_obj_t * slider;
lv_obj_t * chart;
lv_chart_series_t * ser1;
lv_chart_series_t * ser2;
int start_flag=0;
int Target_Speed;
lv_obj_t * kb;
int Constant_speed=0;
float err;
float err_last;
float intergral;
float Read_Date(lv_obj_t * obj)
{
    const char *test = lv_textarea_get_text(obj);
    double temp = strtod(test,NULL);
    float ftemp = atof(test);
    printf("%f\n",ftemp);
    return ftemp;
}

void PID_init(){
	Kp = Read_Date(p_parameter);
	Ki = Read_Date(I_parameter);
	Kd = Read_Date(D_parameter);
}
void event_start(lv_event_t * e)
{
    PID_init();
		set_motor_enable();//ʹ�ܵ��
    Target_Speed=lv_slider_get_value(slider);
		err=0;
		err_last=0;
		intergral=0;
    start_flag=1;
}
void event_end(lv_event_t * e)
{
    start_flag=0;
		set_motor_disable();//�رյ��
    lv_chart_set_all_value(chart, ser2,0);
		lv_chart_set_all_value(chart, ser1,0);
}

void ta_event_cb(lv_event_t * e)
{
    lv_event_code_t code = lv_event_get_code(e);
    lv_obj_t * ta = lv_event_get_target(e);
    if(code == LV_EVENT_CLICKED || code == LV_EVENT_FOCUSED) {
        /*Focus on the clicked text area*/
        if(kb != NULL) lv_keyboard_set_textarea(kb, ta);
    }

    else if(code == LV_EVENT_READY) {
        LV_LOG_USER("Ready, current text: %s", lv_textarea_get_text(ta));
    }
}
void sw_event(lv_event_t * e)
{
    lv_event_code_t code = lv_event_get_code(e);
    lv_obj_t *sw = lv_event_get_target(e);

    if (code == LV_EVENT_VALUE_CHANGED)
    {
        if(lv_obj_get_state(sw) & LV_STATE_CHECKED)
            {
                LV_LOG_USER("ON!");
                Constant_speed=1;
							
							
            }
        else
        {
            LV_LOG_USER("OFF!");
					
            Constant_speed=0;
				
        }

    }
}
void slider_event_cb(lv_event_t * e)
{
    lv_obj_t * slider = lv_event_get_target(e);
    char buf[8];
    lv_snprintf(buf, sizeof(buf), "%d%", (int)lv_slider_get_value(slider));
    lv_label_set_text(slider_label, buf);
    lv_obj_align_to(slider_label, slider, LV_ALIGN_LEFT_MID, -30, 0);
}
void pageview(void)
{
	  lv_obj_t *tabview;
    tabview = lv_tabview_create(lv_scr_act(), LV_DIR_TOP, 30);
    //�ֽ���//
    lv_obj_t *tab1 = lv_tabview_add_tab(tabview, "Input");
    lv_obj_t *tab2 = lv_tabview_add_tab(tabview, "Draw");
	  //����1//
		//Pģ��//
    p_parameter = lv_textarea_create(tab1);
    lv_textarea_set_text(p_parameter, "");
    lv_textarea_set_one_line(p_parameter, true);
    lv_obj_align(p_parameter, LV_ALIGN_TOP_LEFT, 10, 20);
    lv_obj_add_event_cb(p_parameter, ta_event_cb, LV_EVENT_CLICKED, NULL);
		lv_obj_add_event_cb(p_parameter, ta_event_cb, LV_EVENT_FOCUSED, NULL);
		lv_obj_add_event_cb(p_parameter, ta_event_cb, LV_EVENT_READY, NULL);
    lv_obj_set_size(p_parameter, 80, 40);

    
    lv_obj_t * p_label = lv_label_create(tab1);
    lv_label_set_text(p_label, "P setting:");
    lv_obj_align_to(p_label, p_parameter, LV_ALIGN_OUT_TOP_LEFT, 0, 0);

    //Iģ��//
    I_parameter = lv_textarea_create(tab1);
    lv_textarea_set_one_line(I_parameter, true);

    lv_obj_set_size(I_parameter, 80, 40);
    lv_obj_add_event_cb(I_parameter, ta_event_cb, LV_EVENT_CLICKED, NULL);
		lv_obj_add_event_cb(I_parameter, ta_event_cb, LV_EVENT_FOCUSED, NULL);
		lv_obj_add_event_cb(I_parameter, ta_event_cb, LV_EVENT_READY, NULL);
    lv_obj_align(I_parameter, LV_ALIGN_TOP_MID, 0, 20);


    
    lv_obj_t * i_label = lv_label_create(tab1);
    lv_label_set_text(i_label, "I setting");
    lv_obj_align_to(i_label, I_parameter, LV_ALIGN_OUT_TOP_LEFT, 0, 0);
		
		
		//Dģ��//
    D_parameter = lv_textarea_create(tab1);
    lv_textarea_set_one_line(D_parameter, true);

    lv_obj_set_size(D_parameter, 80, 40);
    lv_obj_add_event_cb(D_parameter, ta_event_cb, LV_EVENT_CLICKED, NULL);
		lv_obj_add_event_cb(D_parameter, ta_event_cb, LV_EVENT_FOCUSED, NULL);
		lv_obj_add_event_cb(D_parameter, ta_event_cb, LV_EVENT_READY, NULL);
    lv_obj_align(D_parameter, LV_ALIGN_TOP_RIGHT, -10, 20);


    
    lv_obj_t * d_label = lv_label_create(tab1);
    lv_label_set_text(d_label, "D setting");
    lv_obj_align_to(d_label, D_parameter, LV_ALIGN_OUT_TOP_LEFT, 0, 0);

    //����//
    kb = lv_keyboard_create(tab1);
    lv_keyboard_set_mode(kb,LV_KEYBOARD_MODE_NUMBER);
    lv_keyboard_set_textarea(kb, p_parameter);
		//����2//

		//����//
    chart = lv_chart_create(tab2);
    lv_obj_set_size(chart, 240, 200);
    lv_obj_align(chart, LV_ALIGN_RIGHT_MID, 0, 20);
    lv_chart_set_range(chart,LV_CHART_AXIS_PRIMARY_Y ,-7200, 7200);
    lv_chart_set_div_line_count(chart, 10, 20);
    lv_chart_set_point_count(chart, 1000);

    lv_chart_set_update_mode(chart,LV_CHART_UPDATE_MODE_SHIFT);


    ser1 = lv_chart_add_series(chart, lv_palette_main(LV_PALETTE_RED), LV_CHART_AXIS_PRIMARY_Y);
    ser2 = lv_chart_add_series(chart, lv_palette_main(LV_PALETTE_BLUE), LV_CHART_AXIS_PRIMARY_Y);
    lv_chart_set_all_value(chart, ser2,0);

		//��ť//
    lv_obj_t * btn1 = lv_btn_create(tab2);
    lv_obj_add_event_cb(btn1, event_start, LV_EVENT_SHORT_CLICKED, chart);
    lv_obj_align(btn1, LV_ALIGN_LEFT_MID, 0, 0);
    lv_obj_set_size(btn1, 40, 40);

    lv_obj_t * btn2 = lv_btn_create(tab2);
    lv_obj_add_event_cb(btn2, event_end, LV_EVENT_SHORT_CLICKED, chart);
    lv_obj_set_style_bg_color(btn2,lv_color_hex(0xFF3333), 0);
    lv_obj_align(btn2, LV_ALIGN_LEFT_MID, 60, 0);
    lv_obj_set_size(btn2, 40, 40);
		
		//����//
    lv_obj_t * sw = lv_switch_create(tab2);
    lv_obj_align(sw, LV_ALIGN_LEFT_MID, 0,50);
    lv_obj_set_size(sw, 100,30);
    lv_obj_add_event_cb(sw, sw_event, LV_EVENT_VALUE_CHANGED, NULL);




    slider = lv_slider_create(tab2);
    lv_obj_set_size(slider, 10, 200);
    lv_obj_align_to(slider, chart, LV_ALIGN_LEFT_MID, -30, 0);
    lv_slider_set_range(slider, -7100 ,7100);
    lv_slider_set_value(slider, 0, LV_ANIM_ON);


    slider_label = lv_label_create(tab2);
    lv_label_set_text(slider_label, "0");
    lv_obj_align_to(slider_label, slider, LV_ALIGN_LEFT_MID, -30, 0);
    lv_obj_add_event_cb(slider, slider_event_cb, LV_EVENT_VALUE_CHANGED,NULL);
}


